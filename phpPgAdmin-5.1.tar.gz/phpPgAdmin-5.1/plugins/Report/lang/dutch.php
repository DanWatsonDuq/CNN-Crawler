<?php
	/**
	 * Dutch Language file.
	 */
	//Basic
	$plugin_lang['strplugindescription'] = 'Report plugin';

	//Reports
	$plugin_lang['strreport'] = 'Rapport';
	$plugin_lang['strreports'] = 'Rapporten';
	$plugin_lang['strshowallreports'] = 'Toon alle rapporten';
	$plugin_lang['strnoreports'] = 'Geen rapporten gevonden.';
	$plugin_lang['strcreatereport'] = 'Maak rapport aan';
	$plugin_lang['strreportdropped'] = 'Rapport verwijderd.';
	$plugin_lang['strreportdroppedbad'] = 'Verwijdering van rapport mislukt.';
	$plugin_lang['strconfdropreport'] = 'Weet u zeker dat u het rapport "%s" wilt verwijderen?';
	$plugin_lang['strreportneedsname'] = 'U dient een naam op te geven voor het rapport.';
	$plugin_lang['strreportneedsdef'] = 'U dient SQL op te geven voor het rapport.';
	$plugin_lang['strreportcreated'] = 'Rapport bewaard.';
	$plugin_lang['strreportcreatedbad'] = 'Bewaren van het rapport mislukt.';
?>
